$(function () {
    if (hasOrdering) {
        alert('주문이 있습니다.');
    }
});